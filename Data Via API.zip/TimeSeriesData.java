/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.api_alphavantage;

import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.patriques.AlphaVantageConnector;
import org.patriques.TimeSeries;
import org.patriques.input.timeseries.Interval;
import org.patriques.input.timeseries.OutputSize;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.timeseries.IntraDay;
import org.patriques.output.timeseries.data.StockData;
/**
 *
 * @author Anmol
 */
public class TimeSeriesData {
    public String createFile(String stock)
    {
        try{
            String path="./"+stock+"data.csv";
            FileWriter outputfile = new FileWriter(path,true); 
            CSVWriter writer = new CSVWriter(outputfile);
            
            String[] header = {"Date","Open","High","Low","Close","Volume" };
            System.out.println(Arrays.toString(header));
            writer.writeNext(header); 
            writer.close();
            return path;
        }
        catch(Exception e)
        {
            return "";
        }
        
        
    }
    public void getData(String stk) throws IOException
    {
        String path="./"+stk+"data.csv";
        String apiKey = "UFERJOTI1C9TP8EL";
    int timeout = 3000;
    AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
    TimeSeries stockTimeSeries = new TimeSeries(apiConnector);
        FileWriter outputfile = new FileWriter(path,true); 
        CSVWriter writer = new CSVWriter(outputfile);
        try {
            IntraDay response = stockTimeSeries.intraDay("MSFT", Interval.ONE_MIN, OutputSize.COMPACT);
      Map<String, String> metaData = response.getMetaData();
      System.out.println("Information: " + metaData.get("1. Information"));
      System.out.println("Stock: " + metaData.get("2. Symbol"));
      
            List<StockData> stockData = response.getStockData();
            stockData.forEach((StockData stock) -> {
                String []data={""+stock.getDateTime(),""+stock.getOpen(),""+stock.getHigh(),""+stock.getLow(),""+stock.getClose(),""+stock.getVolume()};
                writer.writeNext(data); 
      });
            
            writer.close();
        }
        catch(AlphaVantageException e)
        {
            String data[]={"NAN","NAN","NAN","NAN","NAN","NAN"};
            writer.writeNext(data);
        }
    }
    public static void main(String args[])
    {
        TimeSeriesData tsd1= new TimeSeriesData();
        String path=tsd1.createFile("MSFT");
        if(path!="")
        {
            try{
                tsd1.getData("MSFT");    
            }
            catch(IOException ioe)
            {

            }
        }
    }
}
