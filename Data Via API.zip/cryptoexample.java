/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.api_alphavantage;

import java.util.List;
import java.util.Map;
import org.patriques.AlphaVantageConnector;
import org.patriques.DigitalCurrencies;
import org.patriques.input.digitalcurrencies.Market;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.digitalcurrencies.IntraDay;
import org.patriques.output.digitalcurrencies.data.SimpelDigitalCurrencyData;

/**
 *
 * @author Anmol
 */
public class cryptoexample {
    public static void main(String[] args) throws InterruptedException {
    String apiKey = "UFERJOTI1C9TP8EL";
    int timeout = 3000;
    AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
    DigitalCurrencies digitalCurrencies = new DigitalCurrencies(apiConnector);

    try {
      IntraDay response = digitalCurrencies.intraDay("BTC", Market.USD);
      Map<String, String> metaData = response.getMetaData();
      System.out.println("Information: " + metaData.get("1. Information"));
      System.out.println("Digital Currency Code: " + metaData.get("2. Digital Currency Code"));

      List<SimpelDigitalCurrencyData> digitalData = response.getDigitalData();
      digitalData.forEach(data -> {
        System.out.println("date:       " + data.getDateTime());
        System.out.println("price A:    " + data.getPriceA());
        System.out.println("price B:    " + data.getPriceB());
        System.out.println("volume:     " + data.getVolume());
        System.out.println("market cap: " + data.getMarketCap());
      });
    } catch (AlphaVantageException e) {
      System.out.println("something went wrong");
    }
//    x++;
//    Thread.sleep(5*1000);
//    }
  }
}
