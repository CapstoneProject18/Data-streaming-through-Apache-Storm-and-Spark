/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.api_alphavantage;

import com.opencsv.CSVWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import org.patriques.AlphaVantageConnector;
import org.patriques.ForeignExchange;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.exchange.CurrencyExchange;
import org.patriques.output.exchange.data.CurrencyExchangeData;

/**
 *
 * @author Anmol
 */
public class forexdata {
    public void getData(String from,String to,String path) throws IOException
    {
        String apiKey = "UFERJOTI1C9TP8EL";
        int timeout = 3000;
        AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
        ForeignExchange foreignExchange = new ForeignExchange(apiConnector);
        
            FileWriter outputfile = new FileWriter(path,true); 

            CSVWriter writer = new CSVWriter(outputfile);
        try {
            CurrencyExchange currencyExchange = foreignExchange.currencyExchangeRate(from, to);
            CurrencyExchangeData currencyExchangeData = currencyExchange.getData();
            String[] data = { ""+currencyExchangeData.getFromCurrencyName(), ""+currencyExchangeData.getToCurrencyName(), ""+currencyExchangeData.getExchangeRate(),""+currencyExchangeData.getTime() }; 
            System.out.println(Arrays.toString(data));
            writer.writeNext(data); 
            writer.close();
        }
        catch(AlphaVantageException e)
        {
            String data[]={"NAN","NAN","NAN","NAN"};
            writer.writeNext(data);
        }
    }
    public String createFile(String f,String t)
    {
        try{
            String path="./"+f+t+"data.csv";
            FileWriter outputfile = new FileWriter(path,true); 
            CSVWriter writer = new CSVWriter(outputfile);
            
            String[] header = {"FCurrency","TCurrency","ExchangeRate","TimeStamp" };
            System.out.println(Arrays.toString(header));
            writer.writeNext(header); 
            writer.close();
            return path;
        }
        catch(Exception e)
        {
            return "";
        }
        
        
    }
    public static void main(String args[])
    {
        forexdata f1=new forexdata();
        String from="INR";
        String to="USD";
        String path=f1.createFile(from, to);
        if(path!="")
        {
            try{
                f1.getData(from, to, path);    
            }
            catch(IOException ioe)
            {

            }
        }
    }
}
