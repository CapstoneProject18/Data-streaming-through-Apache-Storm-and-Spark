/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.api_alphavantage;

import org.patriques.AlphaVantageConnector;
import org.patriques.ForeignExchange;
import org.patriques.output.AlphaVantageException;
import org.patriques.output.exchange.CurrencyExchange;
import org.patriques.output.exchange.data.CurrencyExchangeData;

/**
 *
 * @author Anmol
 */
public class forexexample {
    public static void main(String[] args) throws InterruptedException {
    String apiKey = "UFERJOTI1C9TP8EL";
    int timeout = 3000;
    AlphaVantageConnector apiConnector = new AlphaVantageConnector(apiKey, timeout);
    ForeignExchange foreignExchange = new ForeignExchange(apiConnector);
    int x=0;
    while(x<10)
    {
     try {
      CurrencyExchange currencyExchange = foreignExchange.currencyExchangeRate("USD", "INR");
      CurrencyExchangeData currencyExchangeData = currencyExchange.getData();

      System.out.println("from currency code: " + currencyExchangeData.getFromCurrencyCode());
      System.out.println("from currency name: " + currencyExchangeData.getFromCurrencyName());
      System.out.println("to currency code:   " + currencyExchangeData.getToCurrencyCode());
      System.out.println("to currency name:   " + currencyExchangeData.getToCurrencyName());
      System.out.println("exchange rate:      " + currencyExchangeData.getExchangeRate());
      System.out.println("last refresh:       " + currencyExchangeData.getTime());
    } catch (AlphaVantageException e) {
      e.printStackTrace();
      System.out.println("something went wrong");
    }
     x++;
     Thread.sleep(5*1000);
    }
    
  }
}
