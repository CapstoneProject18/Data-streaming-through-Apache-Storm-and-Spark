CREATE TABLE `users` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `email` varchar(255) NOT NULL,
 `password` varchar(255) NOT NULL,
 `status` enum('0','1') NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
);