<?php 
	@include("class/Login.class.php");
	$Login = new Login();
?>
<!DOCTYPE HTML>
<html lang="zxx">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Capstone Project</title>
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" media="all" />
		<!-- Slick nav CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/slicknav.min.css" media="all" />
		<!-- Iconfont CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/icofont.css" media="all" />
		<!-- Slick CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/slick.css">

		<link rel="stylesheet" href="assets/css/font-awesome.min.css">
		<!-- Owl carousel CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">
		<!-- Popup CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">
		<!-- Switcher CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/switcher-style.css">
		<!-- Animate CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">
		<!-- Main style CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />
		<!-- Responsive CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/responsive.css" media="all" />
		<!-- Favicon Icon -->
		<link rel="icon" type="image/png" href="assets/img/logo1.PNG" />
	</head>
	<body data-spy="scroll" data-target=".header" data-offset="50">
		<!-- Page loader -->
	    <div id="preloader"></div>
		<!-- header section start -->
		<header class="header">
			<div class="container">
				<div class="row flexbox-center">
					<div class="col-lg-2 col-md-3 col-6">
						<div class="logo">
							<a href="#home"><img src="assets/img/logo1.PNG" alt="logo" style="height: 100px" width="200px" /></a>
						</div>
					</div>
					<div class="col-lg-10 col-md-9 col-6">
						<div class="responsive-menu"></div>
					    <div class="mainmenu">
                            <ul id="primary-menu">
                                <li><a class="nav-link active" href="#home">Home</a></li>
                                <li><a class="nav-link" href="#feature">Feature</a></li>
                                <li><a class="nav-link" href="#team">Team</a></li>
                                <li><a class="nav-link" href="#contact">Contact Us</a></li>
                               
                            </ul>
					    </div>
					</div>
				</div>
			</div>
		</header><!-- header section end -->
		<!-- hero area start -->
		<section class="hero-area" id="home">
			<div class="container">
				<div class="row" style="padding-top:80px">
					<div class="col-lg-4 offset-lg-4 panel panel-default" style="padding-bottom:100px">
					<?php $Login->DisplayMessage(); ?>
						<form method="POST">
				<p class="text-center" style="font-size:25px;"><b style="color:white">Login</b></p>
				<hr>
				<div class="form-group">
					<label for="username" style="color:white; font-size:22px">Username:</label>
					<input type="text" name="username" class="form-control" placeholder="username">
				</div>
				<div class="form-group">
					<label for="password" style="color:white ; font-size:22px">Password:</label>
					<input type="password" name="password"  class="form-control" placeholder="password">
				</div>
				<div style="padding-left:120px">
				<button type="submit" name="login_submit" value="Login" class="btn btn-primary btn-lg" style="color:white;"><span class="glyphicon glyphicon-log-in"></span> Login</button></div>
			</form>
				</div>
			</div>
            </div>
		</section><!-- hero area end -->
		<section class="about-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>About Capstone<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Sample Text</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4">
					    <div class="single-about-box">
							<i class="icofont icofont-ruler-pencil"></i>
							<h4>Great Results</h4>
							<p>Description</p>
						</div>
					</div>
					<div class="col-lg-4">
					    <div class="single-about-box active">
							<i class="icofont icofont-computer"></i>
							<h4>Fast Performance</h4>
							<p>Description</p>
						</div>
					</div>
					<div class="col-lg-4">
					    <div class="single-about-box">
							<i class="icofont icofont-headphone-alt"></i>
							<h4>Cross Platfrom</h4>
							<p>Description</p>
						</div>
					</div>
				</div>
			</div>
		</section><!-- about section end -->
		<!-- feature section start -->
		<section class="feature-area ptb-90" id="feature">
			<div class="container">
				<div class="row flexbox-center">
					<div class="col-lg-4">
						<div class="single-feature-box text-lg-right text-center">
							<ul>
								<li>
									<div class="feature-box-info">
										<h4>Multiple Functionalities</h4>
										
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-brush"></i>
									</div>
								</li>
								<li>
									<div class="feature-box-info">
										<h4>Graphical Analysis</h4>
										
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-computer"></i>
									</div>
								</li>
								<li>
									<div class="feature-box-info">
										<h4>Best Performing Stock</h4>
										
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-law-document"></i>
									</div>
								</li>
								<li>
									<div class="feature-box-info">
										<h4>Acess to full functionalities</h4>
										
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-heart-beat"></i>
									</div>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="single-feature-box text-center">
							<img src="assets/img/stock-market.png" alt="feature">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="single-feature-box text-lg-left text-center">
							<ul>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-eye"></i>
									</div>
									<div class="feature-box-info">
										<h4>Secured Access</h4>
										
									</div>
								</li>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-sun-alt"></i>
									</div>
									<div class="feature-box-info">
										<h4>Financial Experts Review</h4>
										
									</div>
								</li>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-code-alt"></i>
									</div>
									<div class="feature-box-info">
										<h4>Worst Performing Index</h4>
										
									</div>
								</li>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-headphone-alt"></i>
									</div>
									<div class="feature-box-info">
										<h4>Helping Supports</h4>
										
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>		
			<section class="team-area ptb-90" id="team">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Meet Our Team<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-3 col-sm-6 offset-lg-1 ">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/naman.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="https://www.facebook.com/namanjain.333"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Naman Shah</h4></a>
								<p>Web and Security Developer </p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 offset-lg-1 col-sm-6 ">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/debanshu.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="https://www.facebook.com/debanshufun"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Debanshu Majumdar</h4></a>
								<p>Spark Developer and Data Analyst</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 offset-lg-1 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/anmol.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="https://www.facebook.com/anmol.bhutada.79"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Anmol Bhutada</h4></a>
								<p>Data Analyst</p>
							</div>
						</div>
					</div>
                </div><br><br>
                <div class="row">
					<div class="col-lg-3 offset-lg-3 col-sm-6 ">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/muskan.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="https://www.facebook.com/profile.php?id=100009327747188"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Muskan Rathore</h4></a>
								<p>UI and Security Designer</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 offset-lg-1 col-sm-6 ">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/manisha.PNG" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="https://www.facebook.com/manisha.baheti.7"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Manisha Baheti</h4></a>
								<p>Storm Developer</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- counter section start -->
		<section class="counter-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-heart-alt"></i>
							<h1><span class="counter">100</span></h1>
							<p>Happy Client</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-protect"></i>
							<h1><span class="counter">45</span></h1>
							<p>Basic Purchases</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-download-alt"></i>
							<h1><span class="counter">55</span></h1>
							<p>Pro Purchases</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-trophy"></i>
                            <h1><span class="counter">15</span></h1>
							<p>Functionalities</p>
						</div>
					</div>
				</div>
			</div>
		</section><!-- counter section end -->
		<!-- google map area start -->
		<div class="google-map"></div>
		<!-- google map area end -->
		<!-- footer section start -->
		<footer class="footer" id="contact">
			<div class="container">
				<div class="row">
                    <div class="col-lg-6">
						<div class="contact-form">
							<h4>Get in Touch</h4>
							<p class="form-message"></p>
							<form id="contact-form" action="#" method="POST">
				                <input type="text" name="name" placeholder="Enter Your Name">
				                <input type="email" name="email" placeholder="Enter Your Email">
				                <input type="text" name="subject" placeholder="Your Subject">
				                <textarea placeholder="Messege" name="message"></textarea>
				                <button type="submit" name="submit">Send Message</button>
				            </form>
						</div>
                    </div>
                    <div class="col-lg-6">
						<div class="contact-address">
							<h4>Address</h4>
							<p>NIIT University, Neemrana</p>
							<ul>
								<li>
									<div class="contact-address-icon">
										<i class="icofont icofont-headphone-alt"></i>
									</div>
									<div class="contact-address-info">
										<a href="callto:+919001002829">+919001002829</a>
										<a href="callto:+918959902296">+918959902296</a>
									</div>
								</li>
								<li>
									<div class="contact-address-icon">
										<i class="icofont icofont-envelope"></i>
									</div>
									<div class="contact-address-info">
										<a href="mailto:naman.shah@st.niituniversity.in">naman.shah@st.niituniversity.in</a>
									</div>
								</li>
								<li>
									<div class="contact-address-icon">
										<i class="icofont icofont-web"></i>
									</div>
									<div class="contact-address-info">
										<a href="www.niituniversity.in">www.capstone-project.com</a>
									</div>
								</li>
							</ul>
						</div>
                    </div>
				</div>
				<div class="row">
                    <div class="col-lg-12">
						<div class="copyright-area">
							<ul>
								<li><a href="https://www.facebook.com/namanjain.333"><i class="icofont icofont-social-facebook"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-twitter"></i></a></li>
								<li><a href="#"><i class="icofont icofont-brand-linkedin"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-google-plus"></i></a></li>
							</ul>
							
						</div>
                    </div>
				</div>
			</div>
		</footer><!-- footer section end -->
		<a href="#" class="scrollToTop">
			<i class="icofont icofont-arrow-up"></i>
		</a>		
		<!-- jquery main JS -->
		<script src="assets/js/jquery.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="assets/js/bootstrap.min.js"></script>
		<!-- Slick nav JS -->
		<script src="assets/js/jquery.slicknav.min.js"></script>
		<!-- Slick JS -->
		<script src="assets/js/slick.min.js"></script>
		<!-- owl carousel JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Popup JS -->
		<script src="assets/js/jquery.magnific-popup.min.js"></script>
		<!-- Counter JS -->
		<script src="assets/js/jquery.counterup.min.js"></script>
		<!-- Counterup waypoints JS -->
		<script src="assets/js/waypoints.min.js"></script>
	    <!-- YTPlayer JS -->
	    <script src="assets/js/jquery.mb.YTPlayer.min.js"></script>
		<!-- jQuery Easing JS -->
		<script src="assets/js/jquery.easing.1.3.js"></script>
		<!-- Gmap JS -->
		<script src="assets/js/gmap3.min.js"></script>
        <!-- Google map api -->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBnKyOpsNq-vWYtrwayN3BkF3b4k3O9A_A"></script>
		<!-- Custom map JS -->
		<script src="assets/js/custom-map.js"></script>
		<!-- WOW JS -->
		<script src="assets/js/wow-1.3.0.min.js"></script>
		<!-- Switcher JS -->
		<script src="assets/js/switcher.js"></script>
		<!-- main JS -->
		<script src="assets/js/main.js"></script>
	</body>
</html>