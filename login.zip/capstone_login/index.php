<?php 
	@include("class/Login.class.php");
	$Login = new Login();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
	<title>Capstone Project</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	</head>
<body>
<div class="container">
	<h1 class="page-header text-center">Data Streaming through Apache Storm and Spark</h1>


<div class="row">
		<div class="col-sm-4 col-sm-offset-4 panel panel-default" style="padding:20px;">
	<?php $Login->DisplayMessage(); ?>
	<form method="POST">
				<p class="text-center" style="font-size:25px;"><b>Login</b></p>
				<hr>
				<div class="form-group">
					<label for="username">Username:</label>
					<input type="text" name="username" class="form-control" placeholder="username">
				</div>
				<div class="form-group">
					<label for="password">Password:</label>
					<input type="password" name="password"  class="form-control" placeholder="password">
				</div>
				<button type="submit" name="login_submit" value="Login" class="btn btn-primary"><span class="glyphicon glyphicon-log-in"></span> Login</button>
			</form>
</body>
</html>



	
			
	
